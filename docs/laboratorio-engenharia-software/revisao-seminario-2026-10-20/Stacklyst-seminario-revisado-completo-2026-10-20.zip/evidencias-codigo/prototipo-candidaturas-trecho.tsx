const STATUS_LABELS: Record<string, { label: string; bg: string; text: string }> = {
  APPLIED: { label: 'Inscrito', bg: 'bg-blue-500/15', text: 'text-blue-400' },
  REVIEWING: { label: 'Em Análise', bg: 'bg-amber-500/15', text: 'text-amber-400' },
  TESTING: { label: 'Desafio Técnico', bg: 'bg-purple-500/15', text: 'text-purple-400' },
  INTERVIEW: { label: 'Entrevista', bg: 'bg-indigo-500/15', text: 'text-indigo-400' },
  ACCEPTED: { label: 'Aprovado', bg: 'bg-emerald-500/15', text: 'text-emerald-400' },
  REJECTED: { label: 'Recusado', bg: 'bg-rose-500/15', text: 'text-rose-400' },
};

function Prototype(){
const job=fixture.job,applicants=fixture.applicants,isExpanded=true,isLoadingApplicants=false,applicantsCount=1,updatingAppId=null;
const toggleExpandJob=()=>{},loadApplications=()=>{},handleUpdateApplicationStatus=()=>{};
return (                  <div
                    key={job.id}
                    className="rounded-3xl bg-dd-surface border border-dd-border overflow-hidden transition-all shadow-sm"
                  >
                    {/* Job Card Header Info */}
                    <div className="p-5 sm:p-6 space-y-4">
                      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                        <div className="space-y-1.5 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-blue-500/15 text-blue-400 border border-blue-500/25">
                              {job.level}
                            </span>
                            <span className="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/25">
                              {job.modality}
                            </span>
                            <span className="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-purple-500/15 text-purple-400 border border-purple-500/25">
                              {job.contract_type}
                            </span>
                            <span
                              className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full border ${
                                job.status === 'OPEN'
                                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/25'
                                  : 'bg-dd-bg text-dd-muted border-dd-border'
                              }`}
                            >
                              {job.status === 'OPEN' ? 'Aberta' : 'Encerrada'}
                            </span>
                          </div>

                          <h3 className="text-lg sm:text-xl font-black text-dd-text tracking-tight">
                            {job.title}
                          </h3>

                          <div className="flex items-center gap-2 text-xs font-bold text-dd-muted flex-wrap">
                            <span className="text-dd-text flex items-center gap-1">
                              {job.company.name}
                              {job.company.is_verified && (
                                <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
                              )}
                            </span>
                            {job.location && (
                              <>
                                <span>•</span>
                                <span className="flex items-center gap-1">
                                  <MapPin className="w-3.5 h-3.5 text-dd-muted" />
                                  {job.location}
                                </span>
                              </>
                            )}
                            {job.salary_min && job.salary_max && (
                              <>
                                <span>•</span>
                                <span className="flex items-center gap-1 text-emerald-400">
                                  <DollarSign className="w-3.5 h-3.5" />
                                  R$ {job.salary_min.toLocaleString('pt-BR')} - R${' '}
                                  {job.salary_max.toLocaleString('pt-BR')}
                                </span>
                              </>
                            )}
                          </div>
                        </div>

                        {/* APPLICANTS COUNTER BADGE */}
                        <div className="flex items-center gap-3 shrink-0 self-start sm:self-auto">
                          <div
                            data-testid={`job-applicants-count-${job.id}`}
                            className={`flex items-center gap-2 px-3.5 py-2 rounded-2xl border font-bold text-xs sm:text-sm transition-all ${
                              applicantsCount > 0
                                ? 'bg-blue-500/15 border-blue-500/40 text-blue-400 shadow-sm'
                                : 'bg-dd-bg/80 border-dd-border/80 text-dd-muted'
                            }`}
                          >
                            <Users className="w-4 h-4 shrink-0" />
                            <span>
                              <strong className="font-black text-dd-text text-sm sm:text-base mr-1">
                                {applicantsCount}
                              </strong>
                              {applicantsCount === 1 ? 'pessoa inscrita' : 'pessoas inscritas'}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Technologies Chips */}
                      {job.technologies && job.technologies.length > 0 && (
                        <div className="flex items-center gap-1.5 flex-wrap pt-1">
                          {job.technologies.map((tech) => (
                            <span
                              key={tech}
                              className="text-[11px] font-mono font-medium px-2 py-0.5 rounded-lg bg-dd-bg border border-dd-border/60 text-dd-muted"
                            >
                              {tech}
                            </span>
                          ))}
                        </div>
                      )}

                      {/* Card Footer Actions */}
                      <div className="flex items-center justify-between gap-3 pt-3 border-t border-dd-border/50 flex-wrap">
                        <button
                          type="button"
                          onClick={() => toggleExpandJob(job.id)}
                          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-dd-border bg-dd-bg hover:bg-dd-surface active:scale-95 text-xs font-black text-dd-text transition-all cursor-pointer"
                        >
                          <Users className="w-3.5 h-3.5 text-blue-400" />
                          <span>
                            {isExpanded
                              ? 'Ocultar Candidatos'
                              : `Ver Inscritos (${applicantsCount})`}
                          </span>
                          {isExpanded ? (
                            <ChevronUp className="w-3.5 h-3.5" />
                          ) : (
                            <ChevronDown className="w-3.5 h-3.5" />
                          )}
                        </button>

                        <Link
                          href={`/jobs/${job.id}`}
                          className="inline-flex items-center gap-1.5 text-xs font-bold text-dd-muted hover:text-blue-400 transition-colors"
                        >
                          <span>Ver vaga pública</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </Link>
                      </div>
                    </div>

                    {/* EXPANDED APPLICANTS DRAWER */}
                    {isExpanded && (
                      <div className="px-5 pb-6 pt-2 bg-dd-bg/40 border-t border-dd-border space-y-4 animate-fade-in">
                        <div className="flex items-center justify-between gap-2 pt-2">
                          <h4 className="text-xs sm:text-sm font-black text-dd-text uppercase tracking-wider flex items-center gap-2">
                            <UserCheck className="w-4 h-4 text-emerald-400" />
                            Candidatos Inscritos ({applicantsCount})
                          </h4>
                          <button
                            type="button"
                            onClick={() => loadApplications(job.id)}
                            disabled={isLoadingApplicants}
                            className="text-[11px] font-bold text-dd-muted hover:text-dd-text flex items-center gap-1 transition-colors cursor-pointer"
                          >
                            <RefreshCw
                              className={`w-3 h-3 ${isLoadingApplicants ? 'animate-spin' : ''}`}
                            />
                            <span>Recarregar</span>
                          </button>
                        </div>

                        {isLoadingApplicants ? (
                          <div className="p-6 text-center text-xs font-bold text-dd-muted">
                            <RefreshCw className="w-4 h-4 mx-auto animate-spin text-blue-400 mb-1" />
                            Carregando perfil dos candidatos inscritos...
                          </div>
                        ) : applicants.length === 0 ? (
                          <div className="p-6 text-center rounded-2xl bg-dd-surface border border-dd-border text-xs text-dd-muted font-medium">
                            Nenhum candidato se inscreveu nesta vaga ainda.
                          </div>
                        ) : (
                          <div className="space-y-3">
                            {applicants.map((app) => {
                              const statusConfig = STATUS_LABELS[app.status] || {
                                label: app.status,
                                bg: 'bg-dd-surface',
                                text: 'text-dd-muted',
                              };
                              const isUpdating = updatingAppId === app.id;

                              return (
                                <div
                                  key={app.id}
                                  className="p-4 rounded-2xl bg-dd-surface border border-dd-border flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all"
                                >
                                  {/* Candidate Profile Details */}
                                  <div className="flex items-center gap-3 min-w-0">
                                    <AuthorAvatar
                                      username={app.user.username}
                                      avatar_url={app.user.avatar_url}
                                      size="md"
                                      className="!w-10 !h-10 border-dd-border"
                                    />
                                    <div className="min-w-0">
                                      <div className="flex items-center gap-2 flex-wrap">
                                        <span className="text-sm font-black text-dd-text truncate">
                                          @{app.user.username}
                                        </span>
                                        <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/25">
                                          {app.user.total_xp} XP
                                        </span>
                                        {app.user.github_username && (
                                          <span className="text-[10px] font-mono text-dd-muted">
                                            gh: @{app.user.github_username}
                                          </span>
                                        )}
                                      </div>
                                      <p className="text-[11px] text-dd-muted font-medium mt-0.5">
                                        Inscrito em{' '}
                                        {new Date(app.created_at).toLocaleDateString('pt-BR')}
                                        {app.stage && (
                                          <span className="ml-2 text-blue-400 font-semibold">
                                            • Etapa: {app.stage.title}
                                          </span>
                                        )}
                                      </p>
                                    </div>
                                  </div>

                                  {/* Status Selector / Actions */}
                                  <div className="flex items-center gap-2 self-start sm:self-center shrink-0">
                                    <span
                                      className={`text-xs font-bold px-2.5 py-1 rounded-xl border border-current/30 ${statusConfig.bg} ${statusConfig.text}`}
                                    >
                                      {statusConfig.label}
                                    </span>

                                    <select
                                      value={app.status}
                                      disabled={isUpdating}
                                      onChange={(e) =>
                                        handleUpdateApplicationStatus(
                                          job.id,
                                          app.id,
                                          e.target.value
                                        )
                                      }
                                      className="bg-dd-bg border border-dd-border rounded-xl px-2.5 py-1 text-xs font-bold text-dd-text outline-none cursor-pointer focus:border-blue-500 disabled:opacity-50"
                                      aria-label={`Atualizar status de @${app.user.username}`}
                                    >
                                      <option value="APPLIED">Inscrito</option>
                                      <option value="REVIEWING">Em Análise</option>
                                      <option value="TESTING">Desafio Técnico</option>
                                      <option value="INTERVIEW">Entrevista</option>
                                      <option value="ACCEPTED">Aprovado</option>
                                      <option value="REJECTED">Recusado</option>
                                    </select>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    )}
                  </div>);}
module.exports=Prototype;